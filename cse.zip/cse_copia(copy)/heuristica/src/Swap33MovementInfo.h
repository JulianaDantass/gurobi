#ifndef CLASS_SWAP33_MOVEMENT_INFO_H
#define CLASS_SWAP33_MOVEMENT_INFO_H

#include <iostream>
#include <vector>
class MovementInfo;

using namespace std;

class Swap33MovementInfo{

    private:
        int movement_value;

    public:
        vector<MovementInfo*> first_trio_cluster;    //primeiro par, o 1 desse par troca com o 1 do second_pair
        vector<MovementInfo*> second_trio_cluster;
        Swap33MovementInfo(vector<MovementInfo*> fp, vector<MovementInfo*> sp, int value);
        int getValue();
};

#endif