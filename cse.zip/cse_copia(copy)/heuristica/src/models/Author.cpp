#include "Author.h"

Author::Author(int id, string name, string university) {
    this->id = id;
    this->name = name;
    this->university = university;
	this->professorSubs = -1;
}

Author::Author(int id, string name, vector<Topic*>& topics) {
    this->id = id;
    this->name = name;
    this->authorTopics = topics;
	this->professorSubs = -1;
}

int Author::getId() {
    return id;
}

void Author::setId(int id) {
    this->id = id;
}

void Author::setTopics(vector<Topic*> &topics) {
    this->authorTopics = topics;
}


void Author::setIsProfessor(bool isProfessor){
	
	this->isProfessor = isProfessor;

}

void Author::setIsExtra(bool isExtra){

    this->isExtra = isExtra;
}


void Author::setIsAvailable(bool available){

	this->isAvailable = available;

}

void Author::setProfessorSubs(int id){

	this->professorSubs = id;
}

string Author::getName() {
    return name;
}

void Author::setName(string name) {
    this->name = name;
}


void Author::setClustersPretend(vector < int >*clusters){
	
	this->clustersPretend = *clusters;

}
void Author::setClustersPretendDemand(vector<pair<int,int>>* clusters){
	
	this->clustersPretendDemand = *clusters;

}

vector<int>* Author::getClustersPretend(){

	return &this->clustersPretend;
}



string Author::getUniversity() {
    return university;
}

void Author::setUniversity(string university) {
    this->university = university;
}

void Author::addConstraint(int day, int slot) {
    constraints.push_back(new TimeConstraint(day, slot));
}

bool Author::hasConstraint(int day, int slot) {
    if (constraints.size() == 0)
        return false;
        
    for (TimeConstraint* t : constraints) {
        if (t->compare(day, slot)) {
            return true;
        }
    }
    return false;
}
