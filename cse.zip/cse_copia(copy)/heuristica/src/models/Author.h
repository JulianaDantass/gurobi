#ifndef AUTHOR_H
#define AUTHOR_H


#include <iostream>
#include "TimeConstraint.h"
#include "Topic.h"
#include <vector>


using namespace std;

class Author {
    private:
        int id;
        string name;
        string university;
        vector<TimeConstraint*> constraints;
        vector<Topic*> authorTopics;
		vector<int>clustersPretend; // indeces dos clusters que um autor pode estar
		vector <pair<int,int>>clustersPretendDemand;
		bool isProfessor;
        bool isExtra;
		bool isAvailable;
		int professorSubs;

    public:
        int index;
        Author(int id, string name, string university);
        Author(int id, string name, vector<Topic*>& topics);
        int getId();
        void setId(int id);
        string getName();
        void setName(string name);
        string getUniversity();
        void setUniversity(string university);
        void addConstraint(int day, int slot);
        bool hasConstraint(int day, int slot);
        void setTopics(vector<Topic*> &topics);
        vector<Topic*>* getAuthorTopics() {return &authorTopics;}
		vector< int>* getClustersPretend();
		void setClustersPretendDemand(vector<pair<int,int>>*clusters);
		vector<pair<int,int>>*getClustersPretendDemand(){return &clustersPretendDemand;};
		void setClustersPretend(vector< int>*clusters);
		void setClsutersPretendDemand(vector<pair<int,int>>*clustersPretendDemand);

		void setIsProfessor(bool isProfessor);
		bool getIsProfessor(){return this->isProfessor;};
        bool getIsExtra(){return this->isExtra;}
        void setIsExtra(bool isExtra);

		/* Verify if professor is available	*/
		bool getIsAvailable(){return this->isAvailable;};
		void setIsAvailable(bool available);
		int getProfessorSubs(){return this->professorSubs;};
		void setProfessorSubs(int id);
};

#endif
