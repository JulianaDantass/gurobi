#include <iostream>
#include <fstream>
#include "utils/InstanceGenerator.h"
#include "utils/InstanceReader.h"
#include "Heuristic.h"

using namespace std;

/*
   inputFileName -> Instancia, contendo quantia de topicos e indice do primeiro topico
   Quantia de autores e indice do primeiro autor, quantia de trabalhos e indice do primeiro trabalho
   Depois temos quantia de sessões paralelas seguidas pelas sessões e por fim temos quantia de prof extra
   outputFileName -> Arquivo de saida
   dictFileName -> dicionario contendo as informações
*/
int runInstanceFromFile(string inputFilename, string outputFilename, string dictFilename)
{
   /* Cria uma classe do tipo instanceReader que gerencia todos os dados da instancia*/
   InstanceReader instanceReader(inputFilename);
   EventInfo *eventInfo = instanceReader.readInstance();

   /* Chamada da heuristica */
   Heuristic heuristic(eventInfo, dictFilename);
   int result = heuristic.solve(&instanceReader);
   
   if(result){
      heuristic.getOutput();
      heuristic.getOutput()->saveOutputIntoFile(outputFilename, (*eventInfo));
   }
   return result;
}

void saveResult(string filename, int result) {
   std::ofstream outfile;
   outfile.open(filename, std::ios_base::app);
   outfile << result << endl;
}

int main(int argc, char** argv) {
   if (argc < 2) {
      cout << "Incorrect number of params!" << endl;
      cout << "You should provide at least two parameters" << endl;
      cout << "input format: ./heuristic <instance path> <output path in json format> <dictionary path>";
      return 0;
   }

   //nome da instancia
   string intputFileName(argv[1]);
   //int result = runInstanceFromFile(intputFileName, argv[2]);
   if (argc == 4) {
		//nome do json
      string outputFileName(argv[2]);
	  //nome do arquivo dicionario
      string dictFilename(argv[3]);
      int result = runInstanceFromFile(intputFileName, outputFileName, dictFilename);
      // saveResult(outputFileName, result);
      
   }

   return 0; 
}
