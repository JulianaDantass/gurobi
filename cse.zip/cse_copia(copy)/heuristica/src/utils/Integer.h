#ifndef HEURISTIC_INTEGER_H
#define HEURISTIC_INTEGER_H

class Integer {
    public:
        int value;

        Integer() {
            value = 0;
        }
        
        Integer(int value) {
            this->value = value;
        }
        
};

#endif