#include "Swap33MovementInfo.h"
#include "MovementInfo.h"

Swap33MovementInfo::Swap33MovementInfo(vector<MovementInfo*> fp, vector<MovementInfo*> sp, int value) {

    this->first_trio_cluster = fp;
    this->second_trio_cluster = sp;
    this->movement_value = value;
}

int Swap33MovementInfo::getValue() {
    
    return this->movement_value;
}