#include "./Swap33Neightborhood.h"

Swap33Neightborhood::Swap33Neightborhood(vector<vector<vector<MovementInfo*>>> *movements, vector<MovementInfo*> *movements_single) {
    this->movementsInfoIn3 = movements;   
    this->movementsSingle = movements_single; 
    bestSwap33Movement = NULL;
}

void Swap33Neightborhood::findBestNeightbor() {       
    bestSwap33Movement = MovementInfo::findBestSwap33Movement();
    //cout << "esses eh o melhor movimento: " << endl;                        //DEBUG
    MovementInfo* primeiro = bestSwap33Movement->first_trio_cluster[0];
    MovementInfo* segundo = bestSwap33Movement->first_trio_cluster[1];
    MovementInfo* terceiro = bestSwap33Movement->first_trio_cluster[2];

    //cout << "do cluster " << primeiro->getCluster()->index << ": " << endl;
    //cout << primeiro->getPaper()->index << ", " << segundo->getPaper()->index << " e " << terceiro->getPaper()->index << endl;

    // primeiro = bestSwap33Movement->second_trio_cluster[0];
    // segundo = bestSwap33Movement->second_trio_cluster[1];
    // terceiro = bestSwap33Movement->second_trio_cluster[2];

    //cout << "para o cluster " << primeiro->getCluster()->index << ": " << endl;
    //cout << primeiro->getPaper()->index << ", " << segundo->getPaper()->index <<  " e " << terceiro->getPaper()->index << endl;
    //getchar();
}

bool Swap33Neightborhood::isObjectiveFunctionBetter() {

    int currentObjValue = MovementInfo::getCurrentObjectiveValue();
    int newObjValue = currentObjValue + bestSwap33Movement->getValue();
    //cout << "valor velho: " << currentObjValue << " valor novo: " << newObjValue << endl; //debug
    return newObjValue > currentObjValue;
}

void Swap33Neightborhood::updateNeightboorhood() {    
    MovementInfo::makeSwap33(bestSwap33Movement, movementsInfoIn3, movementsSingle);       
}