#ifndef SWAP22NEIGHTBORHOOD_H
#define SWAP22NEIGHTBORHOOD_H

#include <vector>

#include "../MovementInfo.h"
#include "../Swap22MovementInfo.h"
#include "./INeighborhood.h"

class Swap22Neightborhood : public INeighborhood {
    private:
        vector<vector<pair<MovementInfo*, MovementInfo*>>>* movementsInfoInPair;
        vector<MovementInfo*>* movementsSingle;
        Swap22MovementInfo* bestSwap22Movement;
    
    public:
        Swap22Neightborhood(vector<vector<pair<MovementInfo*, MovementInfo*>>> *movementsInfo, vector<MovementInfo*> *movements_single);
        void findBestNeightbor();
        bool isObjectiveFunctionBetter();
        void updateNeightboorhood();

};

#endif