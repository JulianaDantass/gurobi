#ifndef MOVENEIGHTBORHOOD_H
#define MOVENEIGHTBORHOOD_H

#include <vector>

#include "../MovementInfo.h"
#include "./INeighborhood.h"

class MoveNeightborhood : public INeighborhood {
    private:
        vector<MovementInfo*> *movementsInfo;
        vector<vector<pair<MovementInfo*, MovementInfo*>>> *movementsInfoIn2;
        vector<vector<vector<MovementInfo*>>> *movementsInfoIn3;
        MovementInfo *bestMovementInfo;
    
    public:
        MoveNeightborhood(vector<MovementInfo*> *movementsInfo, vector<vector<pair<MovementInfo*, MovementInfo*>>> *pairs, vector<vector<vector<MovementInfo*>>> *movementsInfoIn3);
        void findBestNeightbor();
        bool isObjectiveFunctionBetter();
        void updateNeightboorhood();
};

#endif