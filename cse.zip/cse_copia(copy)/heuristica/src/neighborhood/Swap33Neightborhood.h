#ifndef SWAP33NEIGHTBORHOOD_H
#define SWAP33NEIGHTBORHOOD_H

#include <vector>

#include "../MovementInfo.h"
#include "../Swap33MovementInfo.h"
#include "./INeighborhood.h"

class Swap33Neightborhood : public INeighborhood {
    private:
        vector<vector<vector<MovementInfo*>>>* movementsInfoIn3;
        vector<MovementInfo*>* movementsSingle;
        Swap33MovementInfo* bestSwap33Movement;
    
    public:
        Swap33Neightborhood(vector<vector<vector<MovementInfo*>>> *movementsInfo, vector<MovementInfo*> *movements_single);
        void findBestNeightbor();
        bool isObjectiveFunctionBetter();
        void updateNeightboorhood();

};


#endif