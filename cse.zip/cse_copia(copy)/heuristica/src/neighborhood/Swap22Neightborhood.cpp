#include "./Swap22Neightborhood.h"

Swap22Neightborhood::Swap22Neightborhood(vector<vector<pair<MovementInfo*, MovementInfo*>>> *movements, vector<MovementInfo*> *movements_single) {
    this->movementsInfoInPair = movements;   
    this->movementsSingle = movements_single; 
    bestSwap22Movement = NULL;
}

void Swap22Neightborhood::findBestNeightbor() {       
    bestSwap22Movement = MovementInfo::findBestSwap22Movement();

    //cout << "esses eh o melhor movimento: " << endl;                         //DEBUG
    MovementInfo* primeiro = bestSwap22Movement->first_pair_cluster.first;
    MovementInfo* segundo = bestSwap22Movement->second_pair_cluster.first;
    //cout << primeiro->getPaper()->index << " troca com " << segundo->getPaper()->index << endl;
    //cout << "cluster antigo: " << primeiro->getCluster()->index << " ";
    //cout << "cluster novo: " << segundo->getCluster()->index << endl;

    // primeiro = bestSwap22Movement->first_pair_cluster.second;
    // segundo = bestSwap22Movement->second_pair_cluster.second;
    
    //cout << primeiro->getPaper()->index << " troca com " << segundo->getPaper()->index << endl;
}

bool Swap22Neightborhood::isObjectiveFunctionBetter() {

    int currentObjValue = MovementInfo::getCurrentObjectiveValue();
    int newObjValue = currentObjValue + bestSwap22Movement->getValue();
    //cout << "valor velho: " << currentObjValue << " valor novo: " << newObjValue << endl;// getchar(); //debug
    return newObjValue > currentObjValue;
}

void Swap22Neightborhood::updateNeightboorhood() {    
    MovementInfo::makeSwap22(bestSwap22Movement, movementsInfoInPair, movementsSingle);        
}