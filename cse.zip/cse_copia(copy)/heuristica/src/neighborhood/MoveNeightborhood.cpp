#include "./MoveNeightborhood.h"
#include "../ClustersInfo.h"

MoveNeightborhood::MoveNeightborhood(vector<MovementInfo*> *movementsInfo, vector<vector<pair<MovementInfo*, MovementInfo*>>> *pairs, vector<vector<vector<MovementInfo*>>> *triples) {
    this->movementsInfo = movementsInfo;
    this->movementsInfoIn2 = pairs;
    this->movementsInfoIn3 = triples;
}

void MoveNeightborhood::findBestNeightbor() {
    bestMovementInfo = NULL;
    for (auto m : *movementsInfo) {
        m->calculateBestPaperMovement();
    }     
    
    bestMovementInfo = movementsInfo->at(0);
    int size = movementsInfo->size();
    for (int i = 1; i < size; i++) {
        if(movementsInfo->at(i)->getBestMovementValue() > bestMovementInfo->getBestMovementValue()) {
            bestMovementInfo = movementsInfo->at(i);
        }
    }
}

bool MoveNeightborhood::isObjectiveFunctionBetter() {
    int currentObjValue = MovementInfo::getCurrentObjectiveValue();
    int newObjValue = currentObjValue + bestMovementInfo->getBestMovementValue();
    //cout << "valor velho: " << currentObjValue << " valor novo: " << newObjValue << endl; //debug
    return newObjValue > currentObjValue;
}

void MoveNeightborhood::updateNeightboorhood() {
    bestMovementInfo->makeMoveMovement(movementsInfo, movementsInfoIn2, movementsInfoIn3);

    // string removeMovement = MovementInfo::removeValueToString(movementsInfo);
    // string swapMovement = MovementInfo::swapTableToString();
    // string insertMovement = MovementInfo::insertTableToString();

    // vector<MovementInfo*> moves;
    // for (Cluster *c : *ClustersInfo::clusters) {
    //     vector<MovementInfo*>* clusterMovements = c->calculateRemoveMovement();
    //     for (MovementInfo* m : *clusterMovements) {
    //         moves.push_back(m);
    //     }
    // }

    // for (MovementInfo* m : *movementsInfo) {
    //     m->calculateInsertMovements();
    // }
    // for (MovementInfo* m : *movementsInfo) {
    //     m->calculateSwapMovements(movementsInfo);
    // }

    // string removeMovement2 = MovementInfo::removeValueToString(&moves);
    // if (removeMovement.compare(removeMovement2) != 0) {
    //     cout << "divergência remove (move): " << endl;
    //     cout << removeMovement << endl;
    //     cout << removeMovement2 << endl;
    //     abort();
    // }

    // string insertMovement2 = MovementInfo::insertTableToString();
    // if (insertMovement.compare(insertMovement2) != 0) {
    //     cout << "divergência insert (move): " << endl;
    //     cout << insertMovement << endl;
    //     cout << insertMovement2 << endl;
    //     abort();
    // }

    // string swapMovement2 = MovementInfo::swapTableToString();
    // if (swapMovement.compare(swapMovement2) != 0) {
    //     cout << swapMovement << endl;
    //     cout << swapMovement2 << endl;
    //     cout << "divergência swap (move): " << endl;
    //     abort();
    // }
}
