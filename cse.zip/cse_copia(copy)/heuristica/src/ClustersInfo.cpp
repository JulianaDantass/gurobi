#include "ClustersInfo.h"
#include "models/Paper.h"
#include "./utils/delete_vector.h"

vector<Cluster*> *ClustersInfo::clusters;
vector<vector<Integer*>> ClustersInfo::insertMovements;
vector<vector<SwapMovementInfo*>> ClustersInfo::swapMovements;
vector<vector<vector<Swap22MovementInfo*>>> ClustersInfo::swap22Movements;
vector<vector<vector<Swap33MovementInfo*>>> ClustersInfo::swap33Movements;
//vector<Swap33MovementInfo*> ClustersInfo::swap33Movements;
int ClustersInfo::swapMovementsSize;
bool ClustersInfo::created = false;
int ClustersInfo::numPapers;
int ClustersInfo::numClusters;


void ClustersInfo::Configure(int numPapers, int numClusters, vector<Cluster*> *clusters) {    
    ClustersInfo::numPapers = numPapers;
    ClustersInfo::numClusters = numClusters;

    if (!created) {        
        for (int i = 0; i < numPapers; i++)
            insertMovements.push_back(vector<Integer*>(numClusters));
    }
    
    for (int i = 0; i < numPapers; i++) {
        for (int j = 0; j < numClusters; j++) {
            if (created && insertMovements[i][j] != NULL) {
                delete insertMovements[i][j];
            }
            insertMovements[i][j] = NULL;
        }
    }    
   
    for (int i = 0; i < numPapers; i++) {
        if (!created) 
            swapMovements.push_back(vector<SwapMovementInfo*>(numPapers));
        for (int j = 0; j < numPapers; j++) {
            if (created && swapMovements[i][j] != NULL)
                delete swapMovements[i][j];
            swapMovements[i][j] = NULL;
        }
    }

    for (int i = 0; i < clusters->size(); i++){
        if (!created){
           // swap22Movements.push_back(vector<vector<Swap22MovementInfo*>>(clusters->size()-1));
           // swap22Movements[i].push_back(vector<Swap22MovementInfo*>());
            swap33Movements.push_back(vector<vector<Swap33MovementInfo*>>(clusters->size()-1));
            swap33Movements[i].push_back(vector<Swap33MovementInfo*>());
        }
    }

    if (!created)
        created = true;
   
    swapMovementsSize = numPapers;
    ClustersInfo::clusters = clusters;
}

void ClustersInfo::deleteInsertMovement(int paperIndex, int clusterIndex) {
    if (insertMovements[paperIndex][clusterIndex] != NULL) {
        delete insertMovements[paperIndex][clusterIndex];
        insertMovements[paperIndex][clusterIndex] = NULL;
    }
}

void ClustersInfo::setSwapMovement(int paperIndex1, int paperIndex2, SwapMovementInfo* swapMoveInfo) {
    if (ClustersInfo::swapMovements[paperIndex1][paperIndex2] != NULL) {
        delete ClustersInfo::swapMovements[paperIndex1][paperIndex2];
    }
    ClustersInfo::swapMovements[paperIndex1][paperIndex2] = swapMoveInfo;
}


void ClustersInfo::setInsertMovement(int paperIndex, int clusterIndex, int value) {

    //cout << endl << "psera insaper " << paperIndex << "sera inserido em " << clusterIndex << endl; //only debug

    if (insertMovements[paperIndex][clusterIndex] != NULL) {
        insertMovements[paperIndex][clusterIndex]->value = value;
    } else {        
        delete insertMovements[paperIndex][clusterIndex];
        insertMovements[paperIndex][clusterIndex] = new Integer(value);
    }
}

int ClustersInfo::getInsertMovement(int paperIndex, int clusterIndex) {

    if (insertMovements[paperIndex][clusterIndex] == NULL) {
        cout << "insertMovement is NULL: " << paperIndex << ", " << clusterIndex << endl;
        abort();
    }
    return insertMovements[paperIndex][clusterIndex]->value;
}

void ClustersInfo::printSwapMoves() {
    for (int i = 0; i < swapMovementsSize; i++) {
        for (int j = 0; j < swapMovementsSize; j++) {
            cout << (swapMovements[i][j] != NULL ? swapMovements[i][j]->getValue() : -1)<< " ";
        }
        cout << endl;
    }
    cout << endl;
}

void ClustersInfo::printInsertMoves() {
    for (int i = 0; i < numPapers; i++) {
        for (int j = 0; j < numClusters; j++) {
            if (insertMovements[i][j] == NULL)
                cout << "- ";
            else 
                cout << insertMovements[i][j]->value << " ";
        }
        cout << endl;
    }
    cout << endl;
}

void ClustersInfo::clearData() {
    for (int i = 0; i < numPapers; i++) {
        for (int j = 0; j < numClusters; j++) {
            if (insertMovements[i][j] != NULL) {
                delete insertMovements[i][j];
            }
            insertMovements[i][j] = NULL;
        }
    }    
   
    for (int i = 0; i < numPapers; i++) {        
        for (int j = 0; j < numPapers; j++) {
            if (swapMovements[i][j] != NULL)
                delete swapMovements[i][j];
            swapMovements[i][j] = NULL;
        }
    }


    
}

void ClustersInfo::setSwap22Movement(int index_c1, int index_c2, Swap22MovementInfo* info) {
    ClustersInfo::swap22Movements[index_c1][index_c2].push_back(info);
}

void ClustersInfo::setSwap33Movement(int index_c1, int index_c2, Swap33MovementInfo* info) {
    
    ClustersInfo::swap33Movements[index_c1][index_c2].push_back(info);
}

void ClustersInfo::sizeVectorJuliana() {
    
    cout << "size swap22mov: " << swap22Movements.size() << " ";
    cout  << "size swap33mov: " << swap33Movements.size() << " ";
    
}

void ClustersInfo::emptyVectorSwap22(){

    for(int i = 0; i < ClustersInfo::swap22Movements.size(); i++){
        for(int j = 0; j < ClustersInfo::swap22Movements.size(); j++){
            deleteVectorElements(&swap22Movements[i][j]);
        }
    }

    //deleteVectorElements(&swap22Movements);
    // cout << "isso aqui era pra ta zerado : ";
    // sizeVectorJuliana(); 
}

void ClustersInfo::emptyVectorSwap33(){
    
    for(int i = 0; i < ClustersInfo::swap33Movements.size(); i++){
        for(int j = 0; j < ClustersInfo::swap33Movements.size(); j++){
            deleteVectorElements(&swap33Movements[i][j]);
        }
    }
    // cout << "isso aqui era pra ta zerado : ";
    // sizeVectorJuliana(); 
}
