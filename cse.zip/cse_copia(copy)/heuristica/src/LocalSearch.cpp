#include "./LocalSearch.h"
#include <ctime>
#include <cstdlib>
#include "./ClustersInfo.h"
#include "neighborhood/MoveNeightborhood.h"
#include "neighborhood/SwapNeightborhood.h"
#include "neighborhood/Swap22Neightborhood.h"
#include "neighborhood/Swap33Neightborhood.h"
#include "./utils/delete_vector.h"

LocalSearch::LocalSearch(vector<Cluster*> *clusters, EventInfo *event) {
    this->clusters = clusters;    
    int numPapers = event->getPapers().size();
    int numClusters = clusters->size();
    rnvdSolutionStore = RVNDSolutionStore::getInstance();    
    ClustersInfo::Configure(numPapers, numClusters, clusters); 
}

void LocalSearch::initDataStructures() { 


    for (Cluster *c : *clusters) {   

        vector<MovementInfo*>* clusterMovements = c->calculateRemoveMovement();        
        for (MovementInfo* m : *clusterMovements) {
            movementsInfo.push_back(m);
        }

        vector<pair<MovementInfo*, MovementInfo*>> cluster_pairs;
        vector<vector<MovementInfo*>> cluster_trios;
    
        for (size_t i = 0; i < clusterMovements->size(); i++) {
            MovementInfo* m = (*clusterMovements)[i];

            for (size_t j = i + 1; j < clusterMovements->size(); j++) {
                MovementInfo* n = (*clusterMovements)[j];

                   // pair<MovementInfo*, MovementInfo*> pair = {m, n};     //preenchendo o vetor com todos os possiveis pares de movimento
                   // cluster_pairs.push_back(pair);
                    
                    //movementsInfoIn2.push_back(pair);
    
                 for(size_t k = j + 1; k < clusterMovements->size(); k++){                //preenchendo o vetor com todos os possiveis pares de movimento
                        MovementInfo* o = (*clusterMovements)[k];


                  
                        vector<MovementInfo*> trio = {m, n, o};
                //        // cout << m->getPaper()->index << " " << n->getPaper()->index << " " << o->getPaper()->index << endl; getchar();
                         cluster_trios.push_back(trio);
                                    
                 }
            }
        }
        //movementsInfoIn2.push_back(cluster_pairs);
        movementsInfoIn3.push_back(cluster_trios);

        delete clusterMovements;
    }
    //cout << "size: " << movementsInfo.size();

    for (MovementInfo* m : movementsInfo) {
        m->calculateInsertMovements();
    }

    // for (MovementInfo* m : movementsInfo) {
    //     m->calculateSwapMovements(&movementsInfo);
    // } 

    /*
    for (int i = 0; i < movementsInfoIn2.size()-1; i++) {      //calcula os movimentos de swap22
        
        if(movementsInfoIn2[i].size() == 0){
            continue;
        }
        movementsInfoIn2[i][0].first->calculateSwap22Movements(&movementsInfoIn2, i);
    }
    */

    for (int i = 0; i < movementsInfoIn3.size()-1; i++) {      //calcula os movimentos de swap33
        
         if(movementsInfoIn3[i].size() == 0){
             continue;
         }
         movementsInfoIn3[i][0][0]->calculateSwap33Movements(&movementsInfoIn3, i);
    }

}

LocalSearch::~LocalSearch() {
    deleteVectorElements(&movementsInfo);
    //deleteBiVectorElements(&movementsInfoIn3);
    
    ClustersInfo::clearData();
}

INeighborhood* LocalSearch::chooseRandomNeighborhood(vector<INeighborhood*> *list) {
    int index = rand() % list->size();
    // if(index == 0){             //debug
    //     cout << "move---------------" << endl;
    // }else{
    //     cout << "swap---------------" << endl;
    // }
    return list->at(index);
}

int LocalSearch::RVND(vector<Cluster*> &clustersOut, bool &isSoltionFromRVNDStore) {    
    isSoltionFromRVNDStore = false;
    int bestResult = 0;
    
    initDataStructures();
    //cout << "suave" << endl;
    vector<INeighborhood*> neighborhoodList;    
    neighborhoodList.push_back(new MoveNeightborhood(&movementsInfo, &movementsInfoIn2, &movementsInfoIn3));
    //neighborhoodList.push_back(new SwapNeightborhood(&movementsInfo, &movementsInfoIn2));
    //neighborhoodList.push_back(new Swap22Neightborhood(&movementsInfoIn2, &movementsInfo));
    neighborhoodList.push_back(new Swap33Neightborhood(&movementsInfoIn3, &movementsInfo));
    
    while(neighborhoodList.size() > 0) {
        INeighborhood* neighborhood = chooseRandomNeighborhood(&neighborhoodList);

        neighborhood->findBestNeightbor();
        //cout << "esse eh o novo valor inicial do clusters: " << newObjValue << endl;

        // for (Cluster *c : *clusters) {
        //     auto clusterPapers = c->getPapers();  //papers pertencentes ao cluster 1  
        //     cout << "antess papers do cluster " << c->index << ":" << endl;
        //     for (auto p : *clusterPapers)
        //         cout << p->index << " "; 

        //     cout << endl;
        // }

        if (neighborhood->isObjectiveFunctionBetter()) {    
             
            neighborhood->updateNeightboorhood(); 

            // for (Cluster *c : *clusters) {
            //     auto clusterPapers = c->getPapers();  //papers pertencentes ao cluster 1  
            //     cout << "depoiss papers do cluster " << c->index << ":" << endl;
            //     for (auto p : *clusterPapers)
            //         cout << p->index << " "; 

            //     cout << endl;
            // }


            int newObjValue = Cluster::sumClustersValues(this->clusters);
            // cout << "esse eh o novo valor calculado certo: " << newObjValue << endl;   
            // getchar(); 

            int resultFromStore;
            if (rnvdSolutionStore->isSolutionStored(newObjValue, this->clusters, resultFromStore)) {
                clustersOut = *clusters;
                isSoltionFromRVNDStore = true;

                for (auto it = neighborhoodList.begin(); it != neighborhoodList.end();) {
                    auto aux = *it;
                    it = neighborhoodList.erase(it);
                    delete aux;
                }                
                //ClustersInfo::sizeVectorJuliana();
               // ClustersInfo::emptyVectorSwap22();
                ClustersInfo::emptyVectorSwap33();
                return resultFromStore;
            }

            if (newObjValue > bestResult) {
                bestResult = newObjValue;
                //cout << "esse eh o melhor: " << bestResult << endl; 
            }

        } else {       
            neighborhoodList.erase(remove(neighborhoodList.begin(), neighborhoodList.end(), neighborhood), neighborhoodList.end());
            delete neighborhood;            
        }
        
    }
    clustersOut = *clusters;
    //ClustersInfo::sizeVectorJuliana();
   // ClustersInfo::emptyVectorSwap22();
    ClustersInfo::emptyVectorSwap33();
    return bestResult;
}
