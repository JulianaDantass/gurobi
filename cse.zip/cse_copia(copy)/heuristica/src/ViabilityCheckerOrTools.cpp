#include "ViabilityCheckerOrTools.h"
#include <algorithm>
#include <ctime>
#include <string>
#include <cmath>
#include "models/Session.h"
#include "models/Paper.h"
#include "utils/delete_vector.h"


int ViabilityCheckerOrTools::maxParallelSessions = 2;

ViabilityCheckerOrTools::ViabilityCheckerOrTools(vector<Cluster*>* clusters, EventInfo* eventInfo, bool clearTimeSlots /*= true*/) {
    this->clusters = clusters;
    this->eventInfo = eventInfo;
    timeSlots = new vector<TimeSlot*>();
    this->clearTimeSlots = clearTimeSlots;

}

ViabilityCheckerOrTools::~ViabilityCheckerOrTools() {
    if (clearTimeSlots) {
        for (TimeSlot *t: *timeSlots) {
            deleteTimeSlots();
        }
        deleteTimeSlots();
    }

    int numDays = eventInfo->getNumDays();    
    for (int d = 0; d < numDays; d++) {
        delete dayTimeSlots[d];
    }
}

void ViabilityCheckerOrTools::extractTimeSlotsFromSessions() {
    vector<Session*> sessions = eventInfo->getSessions();
    int numDays = eventInfo->getNumDays();    

    DateTime* lastDay = sessions.at(0)->getDateTimeInit();
    DateTime* lastDateTime = sessions.at(0)->getDateTimeInit();

    int dayIndex = 0;
    int index = 0;
    int slotIndex = 0;
    timeSlots = new vector<TimeSlot*>();
    timeSlots->push_back(new TimeSlot(index++, dayIndex, slotIndex, sessions.at(0)));
    int size = sessions.size();
    for (int i = 1; i < size; i++) {
        Session* session = sessions.at(i);
        if (session->isSameDate(lastDay)) {
            if (session->isSameTime(lastDateTime)) {
                int lastTimeSlotIndex = timeSlots->size()-1;
                timeSlots->at(lastTimeSlotIndex)->addSession(session);
            } else {
                slotIndex++;
                lastDateTime = session->getDateTimeInit();
                timeSlots->push_back(new TimeSlot(index++, dayIndex, slotIndex, session));    
            }
        } else {
            slotIndex = 0;
            lastDay = lastDateTime = session->getDateTimeInit();
            dayIndex++;
            timeSlots->push_back(new TimeSlot(index++, dayIndex, slotIndex, session));
        }
    }
    for (int d = 0; d < numDays; d++) {
        dayTimeSlots[d] = new vector<TimeSlot*>();
    }
    for (TimeSlot *t : *timeSlots) {
        dayTimeSlots[t->getDay()]->push_back(t);
    }
}

int ViabilityCheckerOrTools::getMaxTopicsPerDay(Topic *topic) {
    int numPapersInTopic = eventInfo->getPapersTopic()[topic->index].size();
    if (eventInfo->getNumDays() == 1)
        return numPapersInTopic;

    return (numPapersInTopic > 20)
        ? (int) ceil((double)numPapersInTopic / 2)
        : numPapersInTopic;
}

bool ViabilityCheckerOrTools::isViable(int solutionValue, bool isBestSolution) {
    // Retira os times slots das sessões
    extractTimeSlotsFromSessions();
    stringstream bestResultData;
    FILE* file;
    file = fopen("model.txt", "at");
    fprintf(file, "solutionValue: %d\n", solutionValue);
	MPSolver solver("ViabilityChecker", MPSolver::CBC_MIXED_INTEGER_PROGRAMMING);

    const double infinity = solver.infinity();

    vector<Session*> sessions = eventInfo->getSessions();
    int numDays = eventInfo->getNumDays(); 
	
	
    // Init y var
    int clustersSize = clusters->size();  
   
	//MPObjective* const objective = solver.MutableObjective(); 
    //objective->SetMaximization();
	

    vector<vector<vector<MPVariable*>>> y(clustersSize);
    for (int i = 0; i < clustersSize; i++) {
        vector<vector<MPVariable*>> aux(numDays);
        y[i] = aux;

        for (int d = 0; d < numDays; d++) {
            vector<TimeSlot*>& slotsFromDay = *(dayTimeSlots[d]);
            int slotsSize = slotsFromDay.size();
            vector<MPVariable*> aux2(slotsSize);
            y[i][d] = aux2;

            for (int h = 0; h < slotsSize; h++) {
                char var[100];
                sprintf(var, "Y(%d,%d,%d)", i, d, h);
                y[i][d][h] = solver.MakeBoolVar(var);

                TimeSlot *slot = slotsFromDay[h];

                if (slot->clusterCanEnter(clusters->at(i))) {                    
                    validVarMap[y[i][d][h]] = true;
                } else {
                    y[i][d][h] = 0;
                    validVarMap[y[i][d][h]] = false;
                }
            }
        }
    }


    //init x var -> indica se um oritentador a está alocado naquele cluster que está alocado a sessão k
    //
    vector <Author*> authors = eventInfo->getAuthors();
    
    int authorsSize  = authors.size();
    vector < vector <vector < vector < MPVariable*>>>> x(authorsSize);

    //Inicializa em relação aos autores, onde cada autor vai estar relacionado ao cluster e aquela sessãio
	//Os dias são separados em slot de tempo, onde cada slot representa uma parte daquela sessão
    for(int a = 0; a < authorsSize; a++){
		
		if(!authors.at(a)->getIsProfessor() || !authors.at(a)->getIsAvailable())
			continue;


        vector < vector < vector < MPVariable* >>> aux(clustersSize);
        x[a] = aux;

        for(int i = 0; i < clustersSize; i++){

            vector < vector < MPVariable * >> aux2(numDays);
            x[a][i] = aux2;

            for(int d = 0; d < numDays; d++){

                vector < TimeSlot * > & slotsFromDay = *(dayTimeSlots[d]);
                int slotsSize = slotsFromDay.size();
                vector < MPVariable* > aux3(slotsSize);
                x[a][i][d] = aux3;

                // Cada dia possui slots de tempo, o conjunto deles é a nossa sessão
                // então a partir deles verificamos os clusters e asism por diante
                for(int h = 0; h < slotsSize; h++){
                    char var[100];
                    sprintf(var, "X(%d, %d, %d, %d)", a, i, d, h );
                    x[a][i][d][h] = solver.MakeBoolVar(var);
                    TimeSlot *slot = slotsFromDay[h];
                    
                    // Vamos verificar se o cluster pode estar naquele slot
                    if (slot->clusterCanEnter(clusters->at(i))) {
                        // Agora vamos verificar se o author está naquele cluster 
                        validVarMap[x[a][i][d][h]] = clusters->at(i)->authorInCluster(authors[a]);
                        
                    } 
                    else {
                        validVarMap[x[a][i][d][h]] = false;
                    }
                }

            }
        }
    }
    
   
	
	
    /* Criação da FO, a intenção é reduzir a quantidade 
       de extras necessário para cada dia*/
	if(isBestSolution) {
        
		for(int d = 0; d < numDays; d++){
			
			vector < TimeSlot*> &slotsFromDay = *(dayTimeSlots[d]);

			int slotsSize = slotsFromDay.size();
          
            MPObjective* const objective = solver.MutableObjective();                        
			for(int h = 0; h < slotsSize; h++){
	
				for(Author* author: authors){

					if(!author->getIsProfessor())
						continue;
                    vector < int > *clustersPretend = author->getClustersPretend();

					for(int i = 0; i < clustersSize; i++){
                        
                        if(!validVarMap[y[i][d][h]])
                            continue;

						if(find(clustersPretend->begin(), clustersPretend->end(), i) == clustersPretend->end())
							continue;
							
						objective->SetCoefficient(x[author->index][i][d][h],1);
					}
				}
					
				
			}
            objective->SetMinimization();

		}

	}
	
	

    // AddConstraintEveryClusterMustBeUsed
    for (int i = 0; i < clustersSize; i++) {
        MPConstraint* constraint;
        bool create = false;
        for (int d = 0; d < numDays; d++) {
            vector<TimeSlot*>& slotsFromDay = *(dayTimeSlots[d]);
            int slotsSize = slotsFromDay.size();
            for (int h = 0; h < slotsSize; h++) {
                if (validVarMap[y[i][d][h]]) {                    
                    if (!create) {
                        char name[100];
                        sprintf(name, "UseCluster_%d", i);
                        constraint = solver.MakeRowConstraint(1, 1, name);
                        create = true;
                    }
                    constraint->SetCoefficient(y[i][d][h], 1);
                }
            }
        }
    }
    
 
    // AddConstraintAuthorPerParallelSessionsByVinicus
    vector<vector<Paper*>> papersAuthor = eventInfo->getPapersAuthor();
    for (Author* author : authors) {

        for (int d = 0; d < numDays; d++) { 
            vector<TimeSlot*>& slots = *(dayTimeSlots[d]);
            int slotsSize = slots.size();

            for (int h = 0; h < slotsSize; h++) {
                MPConstraint* constraint;
                bool create = false;

                if(!create){
                    char name[100];
                    sprintf(name, "Author_%d_%d_%d", author->index, d, h);
                    constraint = solver.MakeRowConstraint(-infinity, 1, name);
                }
                
                for (int i = 0; i < clustersSize; i++) {
                    if (!validVarMap[y[i][d][h]])
                        continue;
                    
                    vector<Paper*> papers = papersAuthor[author->index];
                    int papersSize = papers.size();
                    Cluster* cluster = (*(clusters))[i];

                    for (int p = 0; p < papersSize; p++) {
                        if (cluster->hasPaper(papers[p])) {
                            constraint->SetCoefficient(y[i][d][h], 1);
                            break;
                        }
                    }
                }

                // SecondPartOfConstraint
				
				// Vetor contém os indices em relacao ao conjunto de clusters geral
				
				if(!author->getIsProfessor())
					continue;

				vector<int> *ClusterIndexes = author->getClustersPretend();

                for (int k = 0; k < ClusterIndexes->size(); k++) {
                    
                    int idCluster = (*(ClusterIndexes))[k];
                
                    
					if(!validVarMap[y[idCluster][d][h]])
						continue;
					
                    
                    constraint->SetCoefficient(x[author->index][idCluster][d][h], 1);
                
				}
				
                
            }
        }
    }


	// AddConstraintLimitedClusterByLeo
	int clustersMax = 2;
	for(Author* author: authors){
		vector < int > *clustersPretend = author->getClustersPretend();
		
		if(!author->getIsProfessor())
			continue;

		MPConstraint* constraint;
		bool create = false;

		for(int d = 0;  d < numDays; d++){
			
			vector < TimeSlot*>& slots = *(dayTimeSlots[d]);
			int slotsSize = slots.size();

			for(int h = 0; h < slotsSize; h++){
				
				for(int i = 0; i < clustersSize; i++){
                    if(!validVarMap[y[i][d][h]])
						continue;
                    
                    if(find(clustersPretend->begin(), clustersPretend->end(), i) == clustersPretend->end())
                        continue;
                        
					if(!create){

						char name[100];
						sprintf(name, "AuthorLimitedCluster_%d", author->index);
						constraint = solver.MakeRowConstraint(-infinity, clustersMax, name);
						create = true;
					}

					constraint->SetCoefficient(x[author->index][i][d][h], 1);
				}
			}
		}

	}
	
    // AddConstraintClusterDemandByLeo
    for(int i = 0; i < clustersSize; i++){
        Cluster* c = ((*clusters))[i];
        int demand = c->getDemand();
	
        
        for(int d = 0; d < numDays; d++){

            vector <TimeSlot*>&slots = *(dayTimeSlots[d]);
            int slotsSize = slots.size();

            for(int h = 0; h < slotsSize; h++){
                
                MPConstraint* constraint;
                bool create = false;
                
                 
                if(!validVarMap[y[i][d][h]])
                    continue;


                if (!create){
                    char name[100];
                    sprintf(name, "ClusterDemand_%d_%d_%d", i, d, h);
                    constraint = solver.MakeRowConstraint(0, 0, name);
                    create = true;
                }

                for(Author* author: authors){
                    if(!author->getIsProfessor())
						continue;

					//Verificamos se o autor pode estar naquele cluster, a partir do seu vetor de clustersPretend
                    vector<int> *ClusterIndexes = author->getClustersPretend();
					
					if((find(ClusterIndexes->begin(), ClusterIndexes->end(), i) ==  ClusterIndexes->end())){
						continue;
					}
					
					vector<pair<int,int>>*clustersIndexesDemand = author->getClustersPretendDemand();
					int coefficient_x = 1;
					for(int k = 0; k < clustersIndexesDemand->size(); k++){

						pair <int,int> suply = clustersIndexesDemand->at(k);
						if(suply.first == i){
							coefficient_x = suply.second;
                            break;
						}

					}
					coefficient_x = 1;
                    constraint->SetCoefficient(x[author->index][i][d][h], coefficient_x);
                }
				
				constraint->SetCoefficient(y[i][d][h], -demand);

            }
        }
    }
    
   
	



    // AddConstraintClustersPerTimeSlot
     for (int d = 0; d < numDays; d++) {
        vector<TimeSlot*> &slots = *(dayTimeSlots[d]);
        int slotsSize = slots.size();
        for (int h = 0; h < slotsSize; h++) {
            MPConstraint* constraint;
            bool create = false;            
            
            for (int i = 0; i < clustersSize; i++) {
                if (!validVarMap[y[i][d][h]])
                    continue;
                
                if (!create) {
                    char name[100];
                    sprintf(name, "ClusterPerTimeSlot_%d_%d", d, h);
                    constraint = solver.MakeRowConstraint(-infinity, slots[h]->getNumSessions(), name);
                    create = true;
                }                
                constraint->SetCoefficient(y[i][d][h], 1);
            }            
        }
    }

    // AddContraintNumPapersPerTimeSlot
    for (int d = 0; d < numDays; d++) {
        vector<TimeSlot*> &slots = *(dayTimeSlots[d]);
        int slotsSize = slots.size();
        for (int h = 0; h < slotsSize; h++) {
            int maxPapersInTimeSlots = slots[h]->getNumPapers();
            MPConstraint* constraint;
            bool create = false;

            for (int i = 0; i < clustersSize; i++) {
                if (!validVarMap[y[i][d][h]])
                    continue;

                Cluster *cluster = (*(clusters))[i];
                int numPapersInCluster = cluster->getPapers()->size();
                if (!create) {
                    char name[100];
                    sprintf(name, "PapersPerTimeSlot_%d_%d", d, h);    
                    constraint = solver.MakeRowConstraint(-infinity, maxPapersInTimeSlots, name);
                    create = true;
                }
                constraint->SetCoefficient(y[i][d][h], numPapersInCluster);
            }            
        }
    }

	string model;
	solver.ExportModelAsLpFormat(false, &model); 
	
	fprintf(file, "%s\n-----------------------------------------------------------------------------------------\n", model.c_str());

	fclose(file);	
	



    //cout << "CBC solving..." << endl;
    const MPSolver::ResultStatus result_status = solver.Solve();
    // Check that the problem has an optimal solution.
    if (result_status != MPSolver::OPTIMAL) {
        //cout << "CBC inviable" << endl;
        return false;
    } 
	
	insertClustersInTimeSlots(y);

    //cout << "CBC viable" << endl;
	/* abort(); */

	int counter = 0;

	
    for (int i = 0; i < clustersSize; i++) {
		Cluster* c = (*(clusters))[i];

		stringstream ss;
		ss << "Cluster(" << i << ") foi alocado as sessoes-> ";
        for (int d = 0; d < numDays; d++) {
            vector < TimeSlot * > & slotsFromDay = *(dayTimeSlots[d]);
            int slotsSize = slotsFromDay.size();
            
            for (int h = 0; h < slotsSize; h++) {

				if(y[i][d][h]->solution_value()){
					
					ss << "dia: " << d << "slot: " << h << endl;
				}

            }
            
		}
		
		c->setSessionsAllocate(ss);
		
		
    }

    counter = 0;
    vector <int> autoresAlocados;
    
	

	for(int i = 0; i < clustersSize; i++){

		Cluster* c = (*(clusters))[i];

		vector < int > professorsExtra;

		for(int d = 0; d < numDays; d++){
			vector < TimeSlot * > &slotsFromDay = *(dayTimeSlots[d]);
			int slotsSize = slotsFromDay.size();

			for(int h = 0; h < slotsSize; h++){
				
				for(int a = 0; a < authorsSize; a++){
					
					if(!authors.at(a)->getIsProfessor() || !authors.at(a)->getIsAvailable())
						continue;

                    // fprintf(file, "x[%d][%d][%d][%d]: ", a, i, d , h);
                    //fprintf(file, "%f ", x[a][i][d][h]->solution_value());
                    if(x[a][i][d][h]->solution_value()){
                        counter++;
                        autoresAlocados.push_back(a);
						professorsExtra.push_back(a);
					
                    }

				}
			}
		}
		
		c->setProfessorsExtra(professorsExtra);
	}
	
    return true;
}

vector<TimeSlot*>* ViabilityCheckerOrTools::getTimeSlots() {    
    return timeSlots;
}

void ViabilityCheckerOrTools::deleteTimeSlots() {
    deleteVector(timeSlots);
}

void ViabilityCheckerOrTools::insertClustersInTimeSlots(vector<vector<vector<MPVariable*>>> &y) {
    int numDays = eventInfo->getNumDays();
    for (int d = 0; d < numDays; d++) {
        vector<TimeSlot*> slots = getTimeSlotsFromDay(d);
        int slotsSize = slots.size();
        for (int h = 0; h < slotsSize; h++) {
            int clustersSize = clusters->size();
            for (int i = 0; i < clustersSize; i++) {
                if (!validVarMap[y[i][d][h]])
                    continue;

                double value = y[i][d][h]->solution_value();             
                if (value > 0.5) {                    
                    slots[h]->addCluster(clusters->at(i)->copy());
                }
            }
        }
    }
}

vector<TimeSlot*> ViabilityCheckerOrTools::getTimeSlotsFromDay(int day) {
    vector<TimeSlot*> result;
    for (TimeSlot* timeslot : *timeSlots) {
        if (timeslot->getDay() == day)
            result.push_back(timeslot);
    }

    sort(result.begin(), result.end(),
        [](TimeSlot *t1, TimeSlot *t2)->bool {
            time_t time1 = t1->getDateTimeInit()->getDateTime();
            time_t time2 = t2->getDateTimeInit()->getDateTime();
            return difftime(time1, time2) < 0.0;
        });
    return result;
}
