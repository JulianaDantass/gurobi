#ifndef CLASS_SWAP22_MOVEMENT_INFO_H
#define CLASS_SWAP22_MOVEMENT_INFO_H

#include <iostream>
#include <vector>
class MovementInfo;

using namespace std;
class Swap22MovementInfo {

    private:
        int movement_value;

    public:
        pair<MovementInfo*, MovementInfo*> first_pair_cluster;    //primeiro par, o 1 desse par troca com o 1 do second_pair
        pair<MovementInfo*, MovementInfo*> second_pair_cluster;
        Swap22MovementInfo(pair<MovementInfo*, MovementInfo*> fp, pair<MovementInfo*, MovementInfo*> sp, int value);
        int getValue();
};

#endif