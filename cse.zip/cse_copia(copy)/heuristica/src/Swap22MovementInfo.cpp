#include "Swap22MovementInfo.h"
#include "MovementInfo.h"

Swap22MovementInfo::Swap22MovementInfo(pair<MovementInfo*, MovementInfo*> fp, pair<MovementInfo*, MovementInfo*> sp, int value) {

    this->first_pair_cluster = fp;
    this->second_pair_cluster = sp;
    this->movement_value = value;
}

int Swap22MovementInfo::getValue() {
    
    return this->movement_value;
}