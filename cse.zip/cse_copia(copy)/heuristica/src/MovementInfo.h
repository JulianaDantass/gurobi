#ifndef CLASS_MOVEMENT_INFO_H
#define CLASS_MOVEMENT_INFO_H

class Cluster;
#include "SwapMovementInfo.h"
#include <iostream>
#include <algorithm>
#include "models/Paper.h"
#include "ClustersInfo.h"
#include "ClustersInfo.h"
#include "Swap22MovementInfo.h"
#include "Swap33MovementInfo.h"

using namespace std;
/**
 * Esta classe representa os dados de um movimento de vizinhança, como benefício do movimento, melhor troca e etc.
 * O objeto Paper está no objeto Cluster em um dado momento.
 * */


class MovementInfo {
    private:
        Paper *paper;
        Cluster *cluster;
        int removeValue;
        int bestClusterIndexToMove; // Melhor índice do cluster (coluna) para o paper ser movido
        int bestMovementValue; // Benefício do melhor movimento de um paper para um cluster
        int bestSwapMovement; // Melhor benefício de troca
        int clusterToSwap; // Índice do cluster para o qual o paper deve ser movido na troca

    public:
        MovementInfo(Paper *paper, Cluster *cluster, int removeValue);
        static int getCurrentObjectiveValue();
        void calculateInsertMovements();
        void recalculateInsertMovementsToClusters(vector<Cluster*> *modifiedClusters, vector<MovementInfo*> *movementsInfo);
        void calculateBestPaperMovement();
        void makeMoveMovement(vector<MovementInfo*> *movementsInfo, vector<vector<pair<MovementInfo*, MovementInfo*>>> *movementsIn2, vector<vector<vector<MovementInfo*>>>* movementsIn3);  //alterado
        void makeMoveMovement(vector<MovementInfo*> *movementsInfo, vector<vector<pair<MovementInfo*, MovementInfo*>>> *movementsIn2,  vector<vector<vector<MovementInfo*>>>* movementsIn3, int clusterIndex); //alterado
        void movePaperToCluster(int clusterIndex);
        void updateSwapMovementsInsideCluster();
        void updateSwap22Movements(int paper_changed, int old_cluster, int new_cluster, vector<MovementInfo*>* moves_single, vector<vector<pair<MovementInfo*, MovementInfo*>>> *moves_pair);  //adicionado
        void updateSwap33Movements(int paper_changed, int old_cluster, int new_cluster, vector<MovementInfo*>& moves_nc, vector<vector<vector<MovementInfo*>>> *moves_triple);
        void calculateSwapMovement(MovementInfo* movement);   //desativado
        void calculateSwapMovements(vector<MovementInfo*> *movements);
        void calculateSwap22Movements(vector<vector<pair<MovementInfo*,MovementInfo*>>> *movements, int index);  //adicionado
        void calculateSwap33Movements(vector<vector<vector<MovementInfo*>>> *movements, int index);  //adicionado
        static void calculateNewSwap22Movements(Swap22MovementInfo* movementDone, vector<pair<MovementInfo*, MovementInfo*>>* movements);  //adicionado

        
        void recalculateSwapMovents(vector<MovementInfo*> *movements);
        void recalculateSwap22Movements(MovementInfo* second, vector<vector<pair<MovementInfo*, MovementInfo*>>>* movements); //adicionado
        void recalculateSwap33Movements(MovementInfo* second, MovementInfo* third, vector<vector<vector<MovementInfo*>>>* movements); //adicionado
        static SwapMovementInfo* findBestSwapMovement();
        static Swap22MovementInfo* findBestSwap22Movement();   //adicionado
        static Swap33MovementInfo* findBestSwap33Movement();   //adicionado
        static void makeSwap(SwapMovementInfo* swapMovement, vector<MovementInfo*> *movementsInfo);
        static void makeSwapMovement(vector<MovementInfo*> *movements, vector<Paper*> *papers);
        static void makeSwap22(Swap22MovementInfo* swap22Movement, vector<vector<pair<MovementInfo*, MovementInfo*>>> *movInfo, vector<MovementInfo*>* move_single);  //adicionado
        static void makeSwap33(Swap33MovementInfo* swap33Movement, vector<vector<vector<MovementInfo*>>>* movInfo, vector<MovementInfo*>* mov_single);  //adicionado

        // métodos para depuração
        static string removeValueToString(vector<MovementInfo*> *movements);
        static string swapTableToString();
        static string insertTableToString();
        // getters ad setters
        Paper *getPaper();
        void setPaper(Paper* paper);
        Cluster *getCluster();
        void setCluster(Cluster* cluster);
        int getRemoveValue();
        void setRemoveValue(int removeValue);                
        int getBestMovementValue();        
        int getBestSwapMovement();
        void setBestSwapMovement(int bestSwapMovement);
        int getClusterToSwap();
        void setClusterToSwap(int clusterToSwap);
        void updateRemoveValue();
        int getBestClusterIndexToMove();

        string toString();
};


#endif
