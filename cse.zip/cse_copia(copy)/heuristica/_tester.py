import os
import subprocess
import tempfile

list_path = os.path.abspath("../")
#f = open(list_path)

from os import listdir
from os.path import isfile, join
#instdir ="instances/set-P"

#inst_files = [f for f in listdir(instdir) if isfile(join(os.path.abspath("instances/set-P") , f))]

media_tempo = 0
media_escalo = 0
media_sol_total = 0
media_sol_ils = 0
cont2 = 10   #pois são 10 execucoes
tentativas = 0
#print(inst_files)
arq= open("resultsTEXT/results_swap33.txt", "a")   
while(1):
    #print("./rvrprd -i "+join(instdir, inst))
    #os.system("./pdprings -i "+join(instdir, inst) )

    cmd_line = ["./heuristic", "../instances_enic/enic22/campus2/instance_campus2_21.txt", "alterado_a22_c1_d21.json", "../instances_enic/enic22/campus2/dictionary_campus2_21.txt"]
    print(cmd_line)

    tentativas += 1

    with tempfile.TemporaryFile() as tempf:
        proc = subprocess.Popen(cmd_line, stdout=tempf)

        proc.wait()
        tempf.seek(0)
        output = str(tempf.read().decode("utf-8"))

        splited= output.split("\n")

        # busca = "Solution value = 0" 
        # cont= 0
        # for s in splited:
        #     if busca in s:    #encontrar infeasible
        #         encontrado = "Solution value = 0"
        #         cont= cont + 1
        #         break
            
        #if cont == 0:  #se nao for infeasible
        #    if splited == '': 
        #        break
        print(splited)
        encontrado= splited [len(splited)-2]

         
        resultados= encontrado.split(' ')
        #print(resultados)
        if (len(resultados) > 5):
            media_tempo += float(resultados[2])
            media_escalo += float(resultados[5])
            media_sol_ils += float(resultados[8]) 
            media_sol_total += float(resultados[10]) 
            cont2 = cont2-1

        if cont2 == 0 or cont2 < 0:
            break
        
      
        #printando as instancias e os resultados num txt
arq.write("saida_a22_c2_d21- tent: " + str(tentativas) +  "- tempo total/escal: " + str(media_tempo/10.0) + "/ " + str(media_escalo/10.0) + " ils: " + str(media_sol_ils/10.0) + " total: " + str(media_sol_total/10.0) + "\n")
arq.close()
    #print(output)
    #exit(0)
#exit(0)
