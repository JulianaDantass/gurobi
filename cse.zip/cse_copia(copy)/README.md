# Um algoritmo híbrido para o Problema de Programação de Sessões Técnicas de Conferências Com Avaliadores

O algoritmo cujo a implementação (na linguagem C++) encontra-se neste repositório apresenta uma combinação de meta-heurísticas com algoritmos exatos de programação matemática. 

## Requisitos para compilação

1. Google OR-Tools

## Passos para executar

Altere no Makefile o caminho para a sua instalação do or-tools.

Em seguida, dentro do diretório heuristica, execute os comandos:

    $ make rebuild

Isso faz com que o build anterior presente no repositório seja excluído e um novo seja criado.

Após realizado o build, o algoritmo está pronto para ser executado.

Ainda no diretório heuristica execute:

    $ ./heuristic <1. caminho para o arquivo de instância> <2. caminho para o arquivo de resultado (.json)> <3. caminho para o arquivo de dicionário>

É necessário que sejam passados os 3 argumentos para a execução nesta ordem.